
import React from 'react'
import { useCart } from '../context/CartContext'

export default function Navbar({ onCartClick }) {
  const { totals } = useCart()
  return (
    <nav className="container-narrow d-flex align-items-center justify-content-between py-3">
      <a href="/" className="d-flex align-items-center gap-2">
        <img src="/rm-icon.svg" alt="Riders Miami" width="28" height="28" />
        <strong>Riders Miami</strong>
      </a>
      <div className="d-flex gap-4 align-items-center">
        <a href="/" className="text-white-50">Home</a>
        <a href="/#catalog" className="text-white-50">Catalog</a>
        <a href="mailto:support@ridersmiami.test" className="text-white-50">Contact</a>
        <button className="btn btn-sm btn-outline-light position-relative" onClick={onCartClick} aria-label="Open cart">
          Cart
          <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-light text-dark">{totals.count}</span>
        </button>
      </div>
    </nav>
  )
}
