
import React, { useState, useEffect } from 'react'
import Navbar from './components/Navbar'
import CartDrawer from './components/CartDrawer'
import Home from './pages/Home'
import Catalog from './pages/Catalog'
import Checkout from './pages/Checkout'
import OrderConfirmed from './pages/OrderConfirmed'
import NotFound from './pages/NotFound'
import { CartProvider } from './context/CartContext'

function useRoute() {
  const [path, setPath] = useState(window.location.pathname)
  useEffect(() => {
    const onClick = (e) => {
      const a = e.target.closest('a[href]')
      if (a && a.getAttribute('href').startsWith('/')) {
        e.preventDefault()
        const to = a.getAttribute('href')
        window.history.pushState({}, '', to)
        setPath(to)
      }
    }
    const onPop = () => setPath(window.location.pathname)
    document.addEventListener('click', onClick)
    window.addEventListener('popstate', onPop)
    return () => { document.removeEventListener('click', onClick); window.removeEventListener('popstate', onPop) }
  }, [])
  return path
}

export default function App(){
  const path = useRoute()
  const [cartOpen, setCartOpen] = useState(false)

  let Page = Home
  if (path === '/catalog') Page = Catalog
  else if (path === '/checkout') Page = Checkout
  else if (path === '/order-confirmed') Page = OrderConfirmed
  else if (path !== '/' && path !== '/index.html') Page = NotFound

  return (
    <CartProvider>
      <Navbar onCartClick={()=>setCartOpen(true)} />
      <main>
        <Page />
      </main>
      <footer className="container-narrow my-5 text-white-50">
        <hr className="border-secondary" />
        <div className="d-flex justify-content-between align-items-center py-2">
          <small>© {new Date().getFullYear()} Riders Miami</small>
          <div className="d-flex gap-3">
            <a href="https://instagram.com" target="_blank">Instagram</a>
            <a href="mailto:support@ridersmiami.test">Support</a>
          </div>
        </div>
      </footer>
      <CartDrawer open={cartOpen} onClose={()=>setCartOpen(false)} />
    </CartProvider>
  )
}
